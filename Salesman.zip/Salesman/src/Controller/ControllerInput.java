package Controller;

import java.util.Scanner;

public class ControllerInput {


    public String input() {
        Scanner in = new Scanner(System.in);
        return in.next();
    }
}
